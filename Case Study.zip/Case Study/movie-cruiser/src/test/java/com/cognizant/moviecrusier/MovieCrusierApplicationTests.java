package com.cognizant.moviecrusier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieCrusierApplicationTests {

	@Test
	void contextLoads() {
	}

}
